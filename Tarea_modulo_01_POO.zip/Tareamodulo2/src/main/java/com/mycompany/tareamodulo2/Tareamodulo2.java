package com.mycompany.tareamodulo2;
class Recursos {

// Primer metodo: Mensaje
public String obtenerMensaje() {
return "Programacion Orientada a Objetos 2024";
}

// Segundo metodo: Mayor o menor de edad
public String verificarEdad(int edad) {
if (edad >= 21) {
return "Mayor de edad";
} else {
return "Menor de edad";
}
}

// Tercer metodo: Resultado de una multiplicacion
public int multiplicar(int a, int b) {
return a * b;
}


// Cuarto metodo: Lista de numeros del 1 al X
public int listadenum(int x) {
return x;
}
}

public class Tareamodulo2 {
public static void main(String[] args) {
Recursos recursos = new Recursos();

// Llamar al primer metodo
System.out.println(recursos.obtenerMensaje());

// Llamar al segundo metodo
int edadEstudiante = 20; // Cambia este valor para probar
System.out.println(recursos.verificarEdad(edadEstudiante));

// Llamar al tercer metodo
int resultadoMultiplicacion = recursos.multiplicar(5, 4);
System.out.println("Resultado de la multiplicacion: " + resultadoMultiplicacion);

// Llamar al cuarto metodo
int listadenumeros = recursos.listadenum(8);
System.out.println("Lista de numeros del 1 al " + listadenumeros + ":");
 for (int i = 1; i <= listadenumeros; i++) {
System.out.println(i);
}
}
}

